#ifndef ADD_H_GUARD
#define ADD_H_GUARD
#define INT16_MAX 1 << 16
int getNextData(FILE *file);
#endif
