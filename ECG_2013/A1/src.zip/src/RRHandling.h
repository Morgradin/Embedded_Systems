int RRfind(BUFFER* inputData, int runCount);
int sizeof_peaks();


// test functions:
void print_list(void);
void print_latest(int backwards);

